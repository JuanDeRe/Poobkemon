package src.presentation;

import javax.swing.*;
import java.awt.*;

public class Battlefield extends JPanel {
    public Battlefield() {
        super();
    }
}
