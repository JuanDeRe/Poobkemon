package src.presentation;

import src.domain.Item;
import src.domain.PoobkemonException;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ItemSelection extends JPanel {
    private final PoobkemonGUI mainGUI;
    private final List<JComboBox<String>> itemSelectors;
    private final List<String> selectedItems;
    private final Map<String, Item> items;
    private Runnable onConfirmCallback;

    public ItemSelection(PoobkemonGUI mainGUI) {
        this.mainGUI = mainGUI;
        this.itemSelectors = new ArrayList<>();
        this.selectedItems = new ArrayList<>();
        this.items = mainGUI.getGame().getItemsMap(); // Necesitarás implementar getItemsMap() en POOBkemon

        setLayout(new BorderLayout());
        initComponents();
        setupItemSelectors();
    }
    public void setOnConfirmCallback(Runnable callback) {
        this.onConfirmCallback = callback;
    }

    private void initComponents() {
        JLabel titleLabel = new JLabel("Select items for battle", SwingConstants.CENTER);
        titleLabel.setFont(PoobkemonGUI.pokemonFont.deriveFont(24f));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titleLabel, BorderLayout.NORTH);
    }

    private void setupItemSelectors() {
        JPanel itemsPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        String[] itemNames = items.keySet().toArray(new String[0]);

        for(int i = 0; i < 4; i++) {
            JComboBox<String> combo = new JComboBox<>(itemNames);
            configureComboBox(combo);
            itemsPanel.add(combo);
            itemSelectors.add(combo);
        }

        add(itemsPanel, BorderLayout.CENTER);
        addControlButtons();
    }

    private JButton createButton(String text, Color bgColor, Runnable action) {
        JButton button = new JButton(text);
        button.setFont(PoobkemonGUI.pokemonFont.deriveFont(18f));
        button.setPreferredSize(new Dimension(150, 40));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.addActionListener(e -> action.run());
        return button;
    }

    // Método configureComboBox adaptado para ítems
    private void configureComboBox(JComboBox<String> combo) {
        combo.setFont(PoobkemonGUI.pokemonFont.deriveFont(16f));
        combo.setPreferredSize(new Dimension(250, 35));

        combo.addItemListener(e -> updateTooltip(combo));

        combo.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                combo.setBorder(BorderFactory.createLineBorder(new Color(0, 120, 215), 2));
                updateTooltip(combo);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                combo.setBorder(UIManager.getBorder("ComboBox.border"));
            }
        });
    }

    // Tooltip con descripción del ítem
    private void updateTooltip(JComboBox<String> combo) {
        String selected = (String) combo.getSelectedItem();
        if (selected != null && items.containsKey(selected)) {
            Item item = items.get(selected);
            combo.setToolTipText("<html><div style='width:300px;'>" +
                    item.getDescription() + "</div></html>"); // Asume que Item tiene getDescription()
        }
    }

    private void addControlButtons() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JButton btnBack = createButton("Back", Color.RED, () -> {
            mainGUI.showPanel(mainGUI.getPanelAbilitiesSelection());
        });

        JButton btnConfirm = createButton("Confirm", Color.GREEN, () -> {
            processSelection();
            if(onConfirmCallback != null) {
                onConfirmCallback.run();
            }
        });

        buttonPanel.add(btnBack);
        buttonPanel.add(btnConfirm);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void processSelection() {
        selectedItems.clear();
        for(JComboBox<String> combo : itemSelectors) {
            String selected = (String) combo.getSelectedItem();
            if(selected != null && !selected.isEmpty()) {
                selectedItems.add(selected);
            }
        }
    }

    public List<Item> getSelectedItems() {
        List<Item> items = new ArrayList<>();
        for(String itemName : selectedItems) {
            try {
                items.add(mainGUI.getGame().createItem(itemName));
            } catch (PoobkemonException e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
        return items;
    }
}