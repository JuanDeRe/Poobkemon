package src.domain;
public class Ability {

}
